import 'dart:async';
import 'package:flutter/material.dart';
import 'package:startapp_sdk/startapp_sdk.dart';

class StartAppAdService {
  static final StartAppSdk _sdk = StartAppSdk();
  static StartAppInterstitialAd? _interstitialAd;
  static StartAppRewardedVideoAd? _rewardedVideoAd;
  static bool _initialized = false;
  static Function? _pendingCallback;

  static void init() {
    if (_initialized) return;
    _initialized = true;
    _sdk.setTestAdsEnabled(true);
    _preloadInterstitial();
    _preloadRewardedVideo();
  }

  static void _preloadInterstitial() {
    _sdk.loadInterstitialAd(
      onAdNotDisplayed: () { _interstitialAd?.dispose(); _interstitialAd = null; _preloadInterstitial(); },
      onAdHidden: () { _interstitialAd?.dispose(); _interstitialAd = null; _preloadInterstitial(); },
    ).then((ad) { _interstitialAd = ad; }).onError((_, __) { _interstitialAd = null; });
  }

  static void _preloadRewardedVideo() {
    _sdk.loadRewardedVideoAd(
      onAdNotDisplayed: () { _rewardedVideoAd?.dispose(); _rewardedVideoAd = null; _preloadRewardedVideo(); },
      onAdHidden: () {
        _rewardedVideoAd?.dispose(); _rewardedVideoAd = null; _preloadRewardedVideo();
        if (_pendingCallback != null) { final cb = _pendingCallback; _pendingCallback = null; cb!(); }
      },
      onVideoCompleted: () {},
    ).then((ad) { _rewardedVideoAd = ad; }).onError((_, __) { _rewardedVideoAd = null; });
  }

  /// Flow: StartApp ad → custom pre-roll skip 5s → onReady
  static void showBeforeWatch(BuildContext context, Function onReady) {
    _showStartAppAd(context, onReady);
  }

  static void _showStartAppAd(BuildContext context, Function onReady) {
    // Thu rewarded video
    if (_rewardedVideoAd != null) {
      _pendingCallback = () => _showPreRoll(context, onReady);
      final ad = _rewardedVideoAd; _rewardedVideoAd = null;
      ad!.show().onError((_, __) { _pendingCallback = null; _showInterstitialAd(context, onReady); });
      return;
    }
    _showInterstitialAd(context, onReady);
  }

  static void _showInterstitialAd(BuildContext context, Function onReady) {
    if (_interstitialAd != null) {
      final ad = _interstitialAd; _interstitialAd = null;
      ad!.show().then((shown) {
        if (shown) _preloadInterstitial();
        _showPreRoll(context, onReady);
      }).onError((_, __) { _showPreRoll(context, onReady); });
      return;
    }
    _showPreRoll(context, onReady);
  }

  /// Custom pre-roll với skip sau 5s
  static void _showPreRoll(BuildContext context, Function onReady) {
    Navigator.push(context, PageRouteBuilder(
      opaque: true, barrierDismissible: false,
      pageBuilder: (_, __, ___) => _PreRollAdWidget(onComplete: () { Navigator.pop(context); onReady(); }),
      transitionsBuilder: (_, a, __, child) => FadeTransition(opacity: a, child: child),
    ));
  }
}

class _PreRollAdWidget extends StatefulWidget {
  final VoidCallback onComplete;
  const _PreRollAdWidget({required this.onComplete});

  @override
  State<_PreRollAdWidget> createState() => _PreRollAdWidgetState();
}

class _PreRollAdWidgetState extends State<_PreRollAdWidget> with SingleTickerProviderStateMixin {
  late Timer _timer;
  int _seconds = 5;
  bool _canSkip = false;
  bool _disposed = false;
  late AnimationController _anim;

  @override
  void initState() {
    super.initState();
    _anim = AnimationController(vsync: this, duration: const Duration(seconds: 5))..forward();
    _timer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (_disposed) { t.cancel(); return; }
      setState(() { _seconds--; if (_seconds <= 0) { _canSkip = true; t.cancel(); } });
    });
  }

  @override
  void dispose() { _disposed = true; _timer.cancel(); _anim.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return Material(color: Colors.black, child: Stack(fit: StackFit.expand, children: [
      // Ad content — thay bằng ảnh/video thật từ server
      const Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
        Icon(Icons.ad_units, color: Colors.amber, size: 64),
        SizedBox(height: 16),
        Text('QUẢNG CÁO', style: TextStyle(color: Colors.white70, fontSize: 14, fontWeight: FontWeight.w600)),
      ])),

      // Label
      Positioned(top: MediaQuery.of(context).padding.top + 12, left: 16,
        child: Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
          decoration: BoxDecoration(color: Colors.amber.shade700, borderRadius: BorderRadius.circular(4)),
          child: const Text('QUẢNG CÁO', style: TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.w700, letterSpacing: 1)),
        )),

      // Skip button
      Positioned(top: MediaQuery.of(context).padding.top + 12, right: 16,
        child: _canSkip
          ? GestureDetector(onTap: widget.onComplete,
              child: Container(padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                decoration: BoxDecoration(color: Colors.black54, borderRadius: BorderRadius.circular(4), border: Border.all(color: Colors.white54, width: 1)),
                child: const Text('Bỏ qua ▸', style: TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.w600)),
              ))
          : Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
              decoration: BoxDecoration(color: Colors.black54, borderRadius: BorderRadius.circular(4)),
              child: Text('Bỏ qua sau ${_seconds}s', style: const TextStyle(color: Colors.white54, fontSize: 12)),
            ),
      ),

      // Progress bar
      Positioned(bottom: 0, left: 0, right: 0,
        child: AnimatedBuilder(animation: _anim, builder: (_, __) =>
          LinearProgressIndicator(value: _anim.value, backgroundColor: Colors.white24, valueColor: const AlwaysStoppedAnimation(Colors.amber), minHeight: 3)),
      ),
    ]));
  }
}
